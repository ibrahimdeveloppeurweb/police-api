package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// Vehicule holds the schema definition for the Vehicule entity.
type Vehicule struct {
	ent.Schema
}

// Mixin of the Vehicule.
func (Vehicule) Mixin() []ent.Mixin {
	return []ent.Mixin{
		CodeMixin{},
	}
}

// Fields of the Vehicule.
func (Vehicule) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		field.String("immatriculation").
			Unique().
			NotEmpty(),
		field.String("marque").
			NotEmpty(),
		field.String("modele").
			NotEmpty(),
		field.String("couleur").
			Optional(),
		field.Int("annee").
			Optional(),
		field.String("type_vehicule").
			Default("VP"), // VP, PL, MOTO, etc.
		field.String("energie").
			Optional(), // Essence, Diesel, Electrique, etc.
		field.Time("date_premiere_mise_en_circulation").
			Optional(),
		field.String("numero_chassis").
			Optional(),
		field.String("proprietaire_nom").
			Optional(),
		field.String("proprietaire_prenom").
			Optional(),
		field.String("proprietaire_adresse").
			Optional(),
		field.String("assurance_compagnie").
			Optional(),
		field.String("assurance_numero").
			Optional(),
		field.Time("assurance_validite").
			Optional(),
		field.Time("controle_technique_validite").
			Optional(),
		field.Bool("active").
			Default(true),
		field.Time("created_at").
			Default(time.Now),
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now),
	}
}

// Edges of the Vehicule.
func (Vehicule) Edges() []ent.Edge {
	return []ent.Edge{
		// Un véhicule peut avoir plusieurs contrôles
		edge.To("controles", Controle.Type),
		// Un véhicule peut avoir plusieurs infractions
		edge.To("infractions", Infraction.Type),
		// Un véhicule peut avoir plusieurs inspections
		edge.To("inspections", Inspection.Type),
	}
}

// Indexes of the Vehicule.
func (Vehicule) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("immatriculation"),
		index.Fields("marque", "modele"),
		index.Fields("proprietaire_nom", "proprietaire_prenom"),
	}
}