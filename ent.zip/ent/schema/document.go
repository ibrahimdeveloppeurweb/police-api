package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// Document holds the schema definition for the Document entity.
type Document struct {
	ent.Schema
}

// Mixin of the Document.
func (Document) Mixin() []ent.Mixin {
	return []ent.Mixin{
		CodeMixin{},
	}
}

// Fields of the Document.
func (Document) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		field.String("nom_fichier").
			NotEmpty(),
		field.String("nom_original").
			NotEmpty(),
		field.String("type_mime").
			NotEmpty(),
		field.Int64("taille").
			Min(0),
		field.String("chemin_stockage").
			NotEmpty(),
		field.String("type_document").
			NotEmpty(), // PHOTO, PERMIS, CARTE_GRISE, ASSURANCE, CONSTAT, etc.
		field.String("description").
			Optional(),
		field.String("hash_fichier").
			Optional(), // Pour vérification intégrité
		field.Bool("public").
			Default(false),
		field.Time("created_at").
			Default(time.Now),
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now),
	}
}

// Edges of the Document.
func (Document) Edges() []ent.Edge {
	return []ent.Edge{
		// Un document peut appartenir à un contrôle
		edge.From("controle", Controle.Type).
			Ref("documents").
			Unique(),
		// Un document peut appartenir à une infraction
		edge.From("infraction", Infraction.Type).
			Ref("documents").
			Unique(),
		// Un document peut appartenir à un PV
		edge.From("proces_verbal", ProcesVerbal.Type).
			Ref("documents").
			Unique(),
		// Un document peut appartenir à un recours
		edge.From("recours", Recours.Type).
			Ref("documents").
			Unique(),
		// Un document est uploadé par un utilisateur
		edge.From("uploaded_by", User.Type).
			Ref("documents").
			Unique().
			Required(),
		// Un document peut être une preuve pour des CheckOptions
		edge.To("check_options", CheckOption.Type),
	}
}

// Indexes of the Document.
func (Document) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("type_document"),
		index.Fields("nom_fichier"),
		index.Fields("created_at"),
		index.Fields("hash_fichier"),
	}
}