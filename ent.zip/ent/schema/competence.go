package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// Competence holds the schema definition for the Competence entity.
type Competence struct {
	ent.Schema
}

// Mixin of the Competence.
func (Competence) Mixin() []ent.Mixin {
	return []ent.Mixin{
		CodeMixin{},
	}
}

// Fields of the Competence.
func (Competence) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		field.String("nom").
			NotEmpty().
			Comment("Nom de la compétence: Contrôle routier, Alcoolémie, Premiers secours, etc."),
		field.String("type").
			Default("SPECIALITE").
			Comment("Type: SPECIALITE, CERTIFICATION, FORMATION"),
		field.String("description").
			Optional().
			Comment("Description de la compétence"),
		field.String("organisme").
			Optional().
			Comment("Organisme délivrant la certification ou formation"),
		field.Time("date_obtention").
			Optional().
			Comment("Date d'obtention de la compétence"),
		field.Time("date_expiration").
			Optional().
			Comment("Date d'expiration si applicable"),
		field.Bool("active").
			Default(true),
		field.Time("created_at").
			Default(time.Now),
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now),
	}
}

// Edges of the Competence.
func (Competence) Edges() []ent.Edge {
	return []ent.Edge{
		// Une compétence appartient à plusieurs agents (many-to-many)
		edge.From("agents", User.Type).
			Ref("competences"),
	}
}

// Indexes of the Competence.
func (Competence) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("type"),
		index.Fields("nom"),
		index.Fields("active"),
	}
}
