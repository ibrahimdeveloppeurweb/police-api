package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// Inspection holds the schema definition for the Inspection entity.
type Inspection struct {
	ent.Schema
}

// Mixin of the Inspection.
func (Inspection) Mixin() []ent.Mixin {
	return []ent.Mixin{
		CodeMixin{},
	}
}

// Fields of the Inspection.
func (Inspection) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		field.String("numero").
			Unique().
			Comment("Référence unique de l'inspection (ex: INS-2025-XXXXX)"),
		field.Enum("statut").
			Values("EN_ATTENTE", "EN_COURS", "TERMINE", "CONFORME", "NON_CONFORME").
			Default("EN_ATTENTE").
			Comment("Statut global de l'inspection"),
		field.Text("observations").
			Optional().
			Comment("Notes additionnelles sur l'inspection"),
		field.Time("date_inspection").
			Default(time.Now).
			Comment("Date de l'inspection"),

		// Compteurs (calculés depuis check_options)
		field.Int("total_verifications").
			Default(0).
			Comment("Nombre total de points à vérifier"),
		field.Int("verifications_ok").
			Default(0).
			Comment("Nombre de points validés"),
		field.Int("verifications_attention").
			Default(0).
			Comment("Nombre de points avec avertissement"),
		field.Int("verifications_echec").
			Default(0).
			Comment("Nombre de points en échec"),
		field.Int("montant_total_amendes").
			Default(0).
			Comment("Montant total des amendes (en FCFA)"),

		// ===== DONNÉES VÉHICULE EMBARQUÉES (dénormalisées pour historique) =====
		field.String("vehicule_immatriculation").
			Comment("Numéro d'immatriculation"),
		field.String("vehicule_marque").
			Comment("Marque du véhicule"),
		field.String("vehicule_modele").
			Comment("Modèle du véhicule"),
		field.Int("vehicule_annee").
			Optional().
			Comment("Année du véhicule"),
		field.String("vehicule_couleur").
			Optional().
			Comment("Couleur du véhicule"),
		field.String("vehicule_numero_chassis").
			Optional().
			Comment("Numéro de châssis/VIN"),
		field.Enum("vehicule_type").
			Values("VOITURE", "MOTO", "CAMION", "BUS", "CAMIONNETTE", "TRACTEUR", "AUTRE").
			Default("VOITURE").
			Comment("Type de véhicule"),

		// ===== DONNÉES CONDUCTEUR EMBARQUÉES (dénormalisées pour historique) =====
		field.String("conducteur_numero_permis").
			Comment("Numéro de permis du conducteur"),
		field.String("conducteur_prenom").
			Comment("Prénom du conducteur"),
		field.String("conducteur_nom").
			Comment("Nom du conducteur"),
		field.String("conducteur_telephone").
			Optional().
			Comment("Téléphone du conducteur"),
		field.String("conducteur_adresse").
			Optional().
			Comment("Adresse du conducteur"),
		field.Enum("conducteur_type_piece").
			Values("CNI", "PASSEPORT", "CARTE_SEJOUR").
			Optional().
			Comment("Type de pièce d'identité"),
		field.String("conducteur_numero_piece").
			Optional().
			Comment("Numéro de pièce d'identité"),

		// ===== DONNÉES ASSURANCE EMBARQUÉES =====
		field.String("assurance_compagnie").
			Optional().
			Comment("Compagnie d'assurance"),
		field.String("assurance_numero_police").
			Optional().
			Comment("Numéro de police d'assurance"),
		field.Time("assurance_date_expiration").
			Optional().
			Nillable().
			Comment("Date d'expiration de l'assurance"),
		field.Enum("assurance_statut").
			Values("ACTIVE", "EXPIREE", "SUSPENDUE", "ANNULEE", "INCONNU").
			Default("INCONNU").
			Comment("Statut de l'assurance"),

		// ===== LOCALISATION =====
		field.String("lieu_inspection").
			Optional().
			Comment("Lieu de l'inspection"),
		field.Float("latitude").
			Optional().
			Nillable().
			Comment("Latitude GPS"),
		field.Float("longitude").
			Optional().
			Nillable().
			Comment("Longitude GPS"),

		// Timestamps
		field.Time("created_at").
			Default(time.Now),
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now),
	}
}

// Edges of the Inspection.
func (Inspection) Edges() []ent.Edge {
	return []ent.Edge{
		// Une inspection est réalisée par un agent/inspecteur
		edge.From("inspecteur", User.Type).
			Ref("inspections_realisees").
			Unique().
			Required(),
		// Commissariat de rattachement (optionnel)
		edge.From("commissariat", Commissariat.Type).
			Ref("inspections").
			Unique(),
		// Lien optionnel vers le véhicule normalisé
		edge.From("vehicule", Vehicule.Type).
			Ref("inspections").
			Unique(),
		// PV/Ticket généré si inspection échouée
		edge.From("proces_verbal", ProcesVerbal.Type).
			Ref("inspection").
			Unique(),
	}
}

// Indexes of the Inspection.
func (Inspection) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("numero"),
		index.Fields("statut"),
		index.Fields("date_inspection"),
		index.Fields("vehicule_immatriculation"),
		index.Fields("conducteur_numero_permis"),
		index.Fields("assurance_statut"),
	}
}
