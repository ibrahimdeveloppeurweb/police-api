package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// Plainte holds the schema definition for the Plainte entity.
type Plainte struct {
	ent.Schema
}

// Mixin of the Plainte.
func (Plainte) Mixin() []ent.Mixin {
	return []ent.Mixin{
		CodeMixin{},
	}
}

// Fields of the Plainte.
func (Plainte) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		field.String("numero").
			Unique(),
		field.String("type_plainte"),
		field.String("description").
			Optional(),
		// Plaignant info
		field.String("plaignant_nom"),
		field.String("plaignant_prenom"),
		field.String("plaignant_telephone").
			Optional(),
		field.String("plaignant_adresse").
			Optional(),
		field.String("plaignant_email").
			Optional(),
		// Dates
		field.Time("date_depot").
			Default(time.Now),
		field.Time("date_resolution").
			Optional().
			Nillable(),
		// Workflow
		field.Enum("etape_actuelle").
			Values("DEPOT", "ENQUETE", "CONVOCATIONS", "RESOLUTION", "CLOTURE").
			Default("DEPOT"),
		field.Enum("priorite").
			Values("BASSE", "NORMALE", "HAUTE", "URGENTE").
			Default("NORMALE"),
		field.Enum("statut").
			Values("EN_COURS", "RESOLU", "CLASSE", "TRANSFERE").
			Default("EN_COURS"),
		// SLA tracking
		field.String("delai_sla").
			Optional(),
		field.Bool("sla_depasse").
			Default(false),
		// Additional info
		field.String("lieu_faits").
			Optional(),
		field.Time("date_faits").
			Optional().
			Nillable(),
		field.String("observations").
			Optional(),
		field.String("decision_finale").
			Optional(),
		// Timestamps
		field.Time("created_at").
			Default(time.Now),
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now),
	}
}

// Edges of the Plainte.
func (Plainte) Edges() []ent.Edge {
	return []ent.Edge{
		// Une plainte appartient à un commissariat
		edge.From("commissariat", Commissariat.Type).
			Ref("plaintes").
			Unique(),
		// Une plainte est assignée à un agent
		edge.From("agent_assigne", User.Type).
			Ref("plaintes_assignees").
			Unique(),
		// Une plainte peut avoir plusieurs convocations
		edge.To("convocations", Convocation.Type),
	}
}

// Indexes of the Plainte.
func (Plainte) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("numero"),
		index.Fields("type_plainte"),
		index.Fields("statut"),
		index.Fields("priorite"),
		index.Fields("etape_actuelle"),
		index.Fields("date_depot"),
	}
}
