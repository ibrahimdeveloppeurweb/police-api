package schema

import (
	"entgo.io/ent"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"entgo.io/ent/schema/mixin"
)

// CodeMixin adds a unique code field to entities.
// The code is auto-generated with format: {PREFIX}-{COMM_CODE}-{YYYYMM}-{SEQ}
// Example: CTRL-DKR01-202512-001, INSP-TH02-202512-042
// For entities without commissariat: USR-202512-001
type CodeMixin struct {
	mixin.Schema
}

// Fields of the CodeMixin.
func (CodeMixin) Fields() []ent.Field {
	return []ent.Field{
		field.String("code").
			Unique().
			Optional().
			Comment("Code unique auto-généré: {PREFIX}-{COMM?}-{YYYYMM}-{SEQ}"),
	}
}

// Indexes of the CodeMixin.
func (CodeMixin) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("code"),
	}
}
