package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// Objectif holds the schema definition for the Objectif entity.
type Objectif struct {
	ent.Schema
}

// Mixin of the Objectif.
func (Objectif) Mixin() []ent.Mixin {
	return []ent.Mixin{
		CodeMixin{},
	}
}

// Fields of the Objectif.
func (Objectif) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		field.String("titre").
			NotEmpty().
			Comment("Titre de l'objectif: Compléter 10 contrôles, Maintenir le taux de performance, etc."),
		field.String("description").
			Optional().
			Comment("Description détaillée de l'objectif"),
		field.String("periode").
			Default("mois").
			Comment("Période de l'objectif: jour, semaine, mois, trimestre, annee"),
		field.Time("date_debut").
			Comment("Date de début de l'objectif"),
		field.Time("date_fin").
			Optional().
			Comment("Date de fin de l'objectif"),
		field.String("statut").
			Default("EN_COURS").
			Comment("Statut: EN_COURS, ATTEINT, NON_ATTEINT, ANNULE"),
		field.Int("valeur_cible").
			Optional().
			Comment("Valeur cible à atteindre (ex: 10 contrôles)"),
		field.Int("valeur_actuelle").
			Default(0).
			Comment("Valeur actuelle atteinte"),
		field.Float("progression").
			Default(0).
			Comment("Pourcentage de progression: 0-100"),
		field.Time("created_at").
			Default(time.Now),
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now),
	}
}

// Edges of the Objectif.
func (Objectif) Edges() []ent.Edge {
	return []ent.Edge{
		// Un objectif est assigné à un agent
		edge.From("agent", User.Type).
			Ref("objectifs").
			Unique().
			Required(),
		// Un objectif peut être assigné par un supérieur
		edge.To("assigne_par", User.Type).
			Unique(),
	}
}

// Indexes of the Objectif.
func (Objectif) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("periode"),
		index.Fields("statut"),
		index.Fields("date_debut"),
	}
}
