package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// ProcesVerbal holds the schema definition for the ProcesVerbal entity.
type ProcesVerbal struct {
	ent.Schema
}

// Mixin of the ProcesVerbal.
func (ProcesVerbal) Mixin() []ent.Mixin {
	return []ent.Mixin{
		CodeMixin{},
	}
}

// Fields of the ProcesVerbal.
func (ProcesVerbal) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		field.String("numero_pv").
			Unique().
			NotEmpty(),
		field.Time("date_emission").
			Default(time.Now),
		field.Float("montant_total").
			Min(0),
		field.Float("montant_majore").
			Optional().
			Min(0),
		field.Time("date_limite_paiement").
			Optional(),
		field.Time("date_majoration").
			Optional(),
		field.String("statut").
			Default("EMIS"), // EMIS, PAYE, CONTESTE, MAJORE, ANNULE
		field.Time("date_paiement").
			Optional(),
		field.Float("montant_paye").
			Optional().
			Min(0),
		field.String("moyen_paiement").
			Optional(), // CB, CHEQUE, ESPECES, VIREMENT
		field.String("reference_paiement").
			Optional(),
		field.Time("date_contestation").
			Optional(),
		field.String("motif_contestation").
			Optional(),
		field.Text("decision_contestation").
			Optional(),
		field.String("tribunal_competent").
			Optional(),
		field.Text("observations").
			Optional(),
		field.Time("created_at").
			Default(time.Now),
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now),
	}
}

// Edges of the ProcesVerbal.
func (ProcesVerbal) Edges() []ent.Edge {
	return []ent.Edge{
		// Un PV contient plusieurs infractions (1 PV pour N infractions d'un même contrôle/inspection)
		edge.To("infractions", Infraction.Type),
		// Un PV peut avoir des paiements
		edge.To("paiements", Paiement.Type),
		// Un PV peut avoir des recours
		edge.To("recours", Recours.Type),
		// Un PV peut avoir des documents
		edge.To("documents", Document.Type),
		// Un PV peut être lié à une inspection
		edge.To("inspection", Inspection.Type).
			Unique(),
		// Un PV peut être lié à un contrôle
		edge.To("controle", Controle.Type).
			Unique(),
	}
}

// Indexes of the ProcesVerbal.
func (ProcesVerbal) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("numero_pv"),
		index.Fields("date_emission"),
		index.Fields("statut"),
		index.Fields("date_limite_paiement"),
		index.Fields("date_paiement"),
	}
}