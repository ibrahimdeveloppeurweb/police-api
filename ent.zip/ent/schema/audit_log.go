package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// AuditLog holds the schema definition for the AuditLog entity.
type AuditLog struct {
	ent.Schema
}

// Mixin of the AuditLog.
func (AuditLog) Mixin() []ent.Mixin {
	return []ent.Mixin{
		CodeMixin{},
	}
}

// Fields of the AuditLog.
func (AuditLog) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		field.Time("timestamp").
			Default(time.Now),
		field.String("action").
			NotEmpty(), // CREATE, UPDATE, DELETE, LOGIN, LOGOUT, etc.
		field.String("resource_type").
			NotEmpty(), // User, Controle, Infraction, etc.
		field.String("resource_id").
			Optional(),
		field.String("user_agent").
			Optional(),
		field.String("ip_address").
			Optional(),
		field.Text("details").
			Optional(), // JSON avec détails de l'action
		field.Text("old_values").
			Optional(), // JSON avec anciennes valeurs
		field.Text("new_values").
			Optional(), // JSON avec nouvelles valeurs
		field.String("session_id").
			Optional(),
		field.String("status").
			Default("SUCCESS"), // SUCCESS, FAILURE, ERROR
		field.String("error_message").
			Optional(),
	}
}

// Edges of the AuditLog.
func (AuditLog) Edges() []ent.Edge {
	return []ent.Edge{
		// Un log est créé par un utilisateur
		edge.From("user", User.Type).
			Ref("audit_logs").
			Unique(),
	}
}

// Indexes of the AuditLog.
func (AuditLog) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("timestamp"),
		index.Fields("action"),
		index.Fields("resource_type"),
		index.Fields("resource_id"),
		index.Fields("status"),
		index.Fields("session_id"),
		index.Fields("ip_address"),
	}
}