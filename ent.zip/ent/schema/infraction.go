package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// Infraction holds the schema definition for the Infraction entity.
type Infraction struct {
	ent.Schema
}

// Mixin of the Infraction.
func (Infraction) Mixin() []ent.Mixin {
	return []ent.Mixin{
		CodeMixin{},
	}
}

// Fields of the Infraction.
func (Infraction) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		field.String("numero_pv").
			Unique().
			Optional(), // Généré après validation
		field.Time("date_infraction").
			Default(time.Now),
		field.String("lieu_infraction").
			NotEmpty(),
		field.String("circonstances").
			Optional(),
		field.Float("vitesse_retenue").
			Optional(),
		field.Float("vitesse_limitee").
			Optional(),
		field.String("appareil_mesure").
			Optional(),
		field.Float("montant_amende").
			Default(0),
		field.Int("points_retires").
			Default(0),
		field.String("statut").
			Default("CONSTATEE"), // CONSTATEE, VALIDEE, CONTESTEE, PAYEE, ANNULEE, ARCHIVEE
		field.Text("observations").
			Optional(),
		field.Bool("flagrant_delit").
			Default(false),
		field.Bool("accident").
			Default(false),
		field.Time("created_at").
			Default(time.Now),
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now),
	}
}

// Edges of the Infraction.
func (Infraction) Edges() []ent.Edge {
	return []ent.Edge{
		// Une infraction appartient à un contrôle (optionnel maintenant car peut venir d'inspection)
		edge.From("controle", Controle.Type).
			Ref("infractions").
			Unique(),
		// Une infraction a un type d'infraction
		edge.From("type_infraction", InfractionType.Type).
			Ref("infractions").
			Unique().
			Required(),
		// Une infraction concerne un véhicule
		edge.From("vehicule", Vehicule.Type).
			Ref("infractions").
			Unique().
			Required(),
		// Une infraction concerne un conducteur
		edge.From("conducteur", Conducteur.Type).
			Ref("infractions").
			Unique().
			Required(),
		// Une infraction appartient à un procès verbal
		edge.From("proces_verbal", ProcesVerbal.Type).
			Ref("infractions").
			Unique(),
		// Une infraction peut avoir des documents
		edge.To("documents", Document.Type),
		// Une infraction peut venir d'un CheckOption FAIL
		edge.From("check_option", CheckOption.Type).
			Ref("infraction").
			Unique(),
	}
}

// Indexes of the Infraction.
func (Infraction) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("numero_pv"),
		index.Fields("date_infraction"),
		index.Fields("statut"),
		index.Fields("lieu_infraction"),
	}
}