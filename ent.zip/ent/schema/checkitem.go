package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// CheckItem - Catalogue unifié de tous les points de vérification pour inspection et contrôle
type CheckItem struct {
	ent.Schema
}

// Mixin of the CheckItem.
func (CheckItem) Mixin() []ent.Mixin {
	return []ent.Mixin{
		CodeMixin{},
	}
}

// Fields of the CheckItem.
func (CheckItem) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		field.String("item_name").
			NotEmpty().
			Comment("Nom du point de vérification (ex: 'Freins', 'Permis de conduire')"),
		field.String("item_code").
			NotEmpty().
			Unique().
			Comment("Code unique (ex: 'SAFETY_BRAKES', 'DOC_LICENSE')"),
		field.Enum("item_category").
			Values("DOCUMENT", "SAFETY", "EQUIPMENT", "LIGHTING", "VISIBILITY").
			Comment("Catégorie du point de vérification"),
		field.Enum("applicable_to").
			Values("INSPECTION", "CONTROL", "BOTH").
			Default("BOTH").
			Comment("Où ce point s'applique: inspections, contrôles, ou les deux"),
		field.String("description").
			Optional().
			Comment("Description détaillée de ce qu'il faut vérifier"),
		field.String("icon").
			Default("check_circle").
			Comment("Nom d'icône pour l'UI"),
		field.Bool("is_mandatory").
			Default(false).
			Comment("Si cette vérification est obligatoire"),
		field.Bool("is_active").
			Default(true).
			Comment("Si ce point est actuellement actif"),
		field.Int("display_order").
			Default(0).
			Comment("Ordre d'affichage dans l'UI"),
		field.Int("fine_amount").
			Default(0).
			Comment("Montant de l'amende si ce point échoue (en FCFA)"),
		field.Int("points_retrait").
			Default(0).
			Comment("Points de permis retirés si ce point échoue"),
		field.Time("created_at").
			Default(time.Now),
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now),
	}
}

// Edges of the CheckItem.
func (CheckItem) Edges() []ent.Edge {
	return []ent.Edge{
		// Un CheckItem peut avoir plusieurs CheckOptions (résultats)
		edge.To("check_options", CheckOption.Type),
		// Un CheckItem peut être lié à un type d'infraction (pour savoir quelle infraction générer si FAIL)
		edge.From("infraction_type", InfractionType.Type).
			Ref("check_items").
			Unique(),
	}
}

// Indexes of the CheckItem.
func (CheckItem) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("item_code"),
		index.Fields("item_category"),
		index.Fields("applicable_to"),
		index.Fields("is_active"),
		index.Fields("display_order"),
	}
}
