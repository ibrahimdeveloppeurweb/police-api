package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// Commissariat holds the schema definition for the Commissariat entity.
// Note: Commissariat has its own 'code' field (commissariat code like "DKR01")
// so it doesn't use CodeMixin
type Commissariat struct {
	ent.Schema
}

// Fields of the Commissariat.
func (Commissariat) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		field.String("nom"),
		field.String("code").
			Unique(),
		field.String("adresse"),
		field.String("ville"),
		field.String("region"),
		field.String("telephone"),
		field.String("email").
			Optional(),
		field.Float("latitude").
			Optional(),
		field.Float("longitude").
			Optional(),
		field.Bool("actif").
			Default(true),
		field.Time("created_at").
			Default(time.Now),
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now),
	}
}

// Edges of the Commissariat.
func (Commissariat) Edges() []ent.Edge {
	return []ent.Edge{
		// Un commissariat a plusieurs agents
		edge.To("agents", User.Type),
		// Un commissariat a plusieurs contrôles
		edge.To("controles", Controle.Type),
		// Un commissariat a plusieurs alertes
		edge.To("alertes", AlerteSecuritaire.Type),
		// Un commissariat a plusieurs plaintes
		edge.To("plaintes", Plainte.Type),
		// Un commissariat a plusieurs convocations
		edge.To("convocations", Convocation.Type),
		// Un commissariat a plusieurs inspections
		edge.To("inspections", Inspection.Type),
		// =============== NOUVELLES RELATIONS ===============
		// Un commissariat a plusieurs équipes
		edge.To("equipes", Equipe.Type),
		// Un commissariat a plusieurs missions
		edge.To("missions", Mission.Type),
	}
}

// Indexes of the Commissariat.
func (Commissariat) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("code"),
		index.Fields("ville"),
		index.Fields("region"),
		index.Fields("actif"),
	}
}
