package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// CheckOption - Résultats des vérifications pour inspections et contrôles
type CheckOption struct {
	ent.Schema
}

// Mixin of the CheckOption.
func (CheckOption) Mixin() []ent.Mixin {
	return []ent.Mixin{
		CodeMixin{},
	}
}

// Fields of the CheckOption.
func (CheckOption) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		// Type de source (polymorphique)
		field.Enum("source_type").
			Values("INSPECTION", "CONTROL").
			Comment("Type de source: inspection ou contrôle"),
		field.String("source_id").
			Comment("ID de l'inspection ou du contrôle"),
		field.Enum("result_status").
			Values("PASS", "FAIL", "WARNING", "NOT_CHECKED").
			Default("NOT_CHECKED").
			Comment("Résultat de la vérification"),
		field.String("notes").
			Optional().
			Comment("Notes sur cette vérification spécifique"),
		// Note: evidence_file_id est géré via l'edge "evidence_file"
		field.Int("fine_amount").
			Default(0).
			Comment("Montant de l'amende appliquée (en FCFA)"),
		field.Time("checked_at").
			Default(time.Now).
			Comment("Date/heure de la vérification"),
		field.Time("created_at").
			Default(time.Now),
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now),
	}
}

// Edges of the CheckOption.
func (CheckOption) Edges() []ent.Edge {
	return []ent.Edge{
		// Un CheckOption appartient à un CheckItem
		edge.From("check_item", CheckItem.Type).
			Ref("check_options").
			Unique().
			Required(),
		// Lien vers le fichier preuve (optionnel)
		edge.From("evidence_file", Document.Type).
			Ref("check_options").
			Unique(),
		// Si FAIL, lien vers l'infraction générée (optionnel)
		edge.To("infraction", Infraction.Type).
			Unique(),
	}
}

// Indexes of the CheckOption.
func (CheckOption) Indexes() []ent.Index {
	return []ent.Index{
		// Un résultat unique par item par source
		index.Fields("source_type", "source_id"),
		index.Fields("result_status"),
	}
}
