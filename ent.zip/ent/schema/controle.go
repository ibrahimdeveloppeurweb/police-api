package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// Controle holds the schema definition for the Controle entity.
type Controle struct {
	ent.Schema
}

// Mixin of the Controle.
func (Controle) Mixin() []ent.Mixin {
	return []ent.Mixin{
		CodeMixin{},
	}
}

// Fields of the Controle.
func (Controle) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		field.String("reference").
			Unique().
			Optional().
			Comment("Référence unique du contrôle (ex: CTRL-2025-XXXXX)"),
		field.Enum("type_controle").
			Values("DOCUMENT", "SECURITE", "GENERAL", "MIXTE").
			Default("GENERAL").
			Comment("Type de contrôle effectué"),
		field.Time("date_controle").
			Default(time.Now).
			Comment("Date et heure du contrôle"),
		field.String("lieu_controle").
			NotEmpty().
			Comment("Lieu spécifique du contrôle"),
		field.Float("latitude").
			Optional().
			Nillable().
			Comment("Latitude GPS"),
		field.Float("longitude").
			Optional().
			Nillable().
			Comment("Longitude GPS"),
		field.Enum("statut").
			Values("EN_COURS", "TERMINE", "CONFORME", "NON_CONFORME").
			Default("EN_COURS").
			Comment("Statut global du contrôle"),
		field.Text("observations").
			Optional().
			Comment("Notes de l'agent sur le contrôle"),

		// Compteurs (calculés depuis check_options)
		field.Int("total_verifications").
			Default(0).
			Comment("Nombre total de points vérifiés"),
		field.Int("verifications_ok").
			Default(0).
			Comment("Nombre de points validés"),
		field.Int("verifications_echec").
			Default(0).
			Comment("Nombre de points en échec"),
		field.Int("montant_total_amendes").
			Default(0).
			Comment("Montant total des amendes (en FCFA)"),

		// ===== DONNÉES VÉHICULE EMBARQUÉES (dénormalisées pour historique) =====
		field.String("vehicule_immatriculation").
			Comment("Numéro d'immatriculation au moment du contrôle"),
		field.String("vehicule_marque").
			Comment("Marque du véhicule"),
		field.String("vehicule_modele").
			Comment("Modèle du véhicule"),
		field.Int("vehicule_annee").
			Optional().
			Comment("Année du véhicule"),
		field.String("vehicule_couleur").
			Optional().
			Comment("Couleur du véhicule"),
		field.String("vehicule_numero_chassis").
			Optional().
			Comment("Numéro de châssis/VIN"),
		field.Enum("vehicule_type").
			Values("VOITURE", "SUV", "CAMION", "CAMIONNETTE", "MOTO", "BUS", "AUTRE").
			Default("VOITURE").
			Comment("Type de véhicule"),

		// ===== DONNÉES CONDUCTEUR EMBARQUÉES (dénormalisées pour historique) =====
		field.String("conducteur_numero_permis").
			Comment("Numéro de permis du conducteur"),
		field.String("conducteur_nom").
			Comment("Nom du conducteur"),
		field.String("conducteur_prenom").
			Comment("Prénom du conducteur"),
		field.String("conducteur_telephone").
			Optional().
			Comment("Téléphone du conducteur"),
		field.String("conducteur_adresse").
			Optional().
			Comment("Adresse du conducteur"),

		// Archivage
		field.Bool("is_archived").
			Default(false).
			Comment("Indique si le contrôle est archivé"),
		field.Time("archived_at").
			Optional().
			Nillable().
			Comment("Date d'archivage du contrôle"),

		// Timestamps
		field.Time("created_at").
			Default(time.Now),
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now),
	}
}

// Edges of the Controle.
func (Controle) Edges() []ent.Edge {
	return []ent.Edge{
		// Un contrôle est effectué par un agent
		edge.From("agent", User.Type).
			Ref("controles").
			Unique().
			Required(),
		// Un contrôle appartient à un commissariat
		edge.From("commissariat", Commissariat.Type).
			Ref("controles").
			Unique(),
		// Lien optionnel vers le véhicule normalisé
		edge.From("vehicule", Vehicule.Type).
			Ref("controles").
			Unique(),
		// Lien optionnel vers le conducteur normalisé
		edge.From("conducteur", Conducteur.Type).
			Ref("controles").
			Unique(),
		// Un contrôle peut avoir plusieurs infractions
		edge.To("infractions", Infraction.Type),
		// Un contrôle peut avoir des documents
		edge.To("documents", Document.Type),
		// Un contrôle peut générer un PV (inverse de ProcesVerbal.controle)
		edge.From("proces_verbal", ProcesVerbal.Type).
			Ref("controle").
			Unique(),
	}
}

// Indexes of the Controle.
func (Controle) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("reference"),
		index.Fields("date_controle"),
		index.Fields("lieu_controle"),
		index.Fields("statut"),
		index.Fields("type_controle"),
		index.Fields("vehicule_immatriculation"),
		index.Fields("conducteur_numero_permis"),
		index.Fields("is_archived"),
	}
}
