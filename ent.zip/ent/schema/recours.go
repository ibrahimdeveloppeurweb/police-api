package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// Recours holds the schema definition for the Recours entity.
type Recours struct {
	ent.Schema
}

// Mixin of the Recours.
func (Recours) Mixin() []ent.Mixin {
	return []ent.Mixin{
		CodeMixin{},
	}
}

// Fields of the Recours.
func (Recours) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		field.String("numero_recours").
			Unique().
			NotEmpty(),
		field.Time("date_recours").
			Default(time.Now),
		field.String("type_recours").
			NotEmpty(), // GRACIEUX, CONTENTIEUX, HIERARCHIQUE
		field.String("motif").
			NotEmpty(),
		field.Text("argumentaire").
			NotEmpty(),
		field.String("statut").
			Default("DEPOSE"), // DEPOSE, EN_COURS, ACCEPTE, REFUSE, ABANDONNE
		field.Time("date_traitement").
			Optional(),
		field.String("decision").
			Optional(), // ACCEPTE, REFUSE_PARTIEL, REFUSE_TOTAL
		field.Text("motif_decision").
			Optional(),
		field.String("autorite_competente").
			Optional(),
		field.String("reference_decision").
			Optional(),
		field.Float("nouveau_montant").
			Optional().
			Min(0),
		field.Time("date_limite_recours").
			Optional(),
		field.Bool("recours_possible").
			Default(true),
		field.Text("observations").
			Optional(),
		field.Time("created_at").
			Default(time.Now),
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now),
	}
}

// Edges of the Recours.
func (Recours) Edges() []ent.Edge {
	return []ent.Edge{
		// Un recours appartient à un PV
		edge.From("proces_verbal", ProcesVerbal.Type).
			Ref("recours").
			Unique().
			Required(),
		// Un recours peut avoir des documents
		edge.To("documents", Document.Type),
		// Un recours est traité par un utilisateur
		edge.From("traite_par", User.Type).
			Ref("recours_traites").
			Unique(),
	}
}

// Indexes of the Recours.
func (Recours) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("numero_recours"),
		index.Fields("date_recours"),
		index.Fields("statut"),
		index.Fields("type_recours"),
		index.Fields("date_traitement"),
	}
}