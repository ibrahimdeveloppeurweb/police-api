package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// Equipe holds the schema definition for the Equipe entity.
type Equipe struct {
	ent.Schema
}

// Mixin of the Equipe.
func (Equipe) Mixin() []ent.Mixin {
	return []ent.Mixin{
		CodeMixin{},
	}
}

// Fields of the Equipe.
func (Equipe) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		field.String("nom").
			NotEmpty().
			Comment("Nom de l'équipe: Équipe Alpha, Équipe Bravo, etc."),
		field.String("zone").
			Optional().
			Comment("Zone d'intervention de l'équipe"),
		field.String("description").
			Optional(),
		field.Bool("active").
			Default(true),
		field.Time("created_at").
			Default(time.Now),
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now),
	}
}

// Edges of the Equipe.
func (Equipe) Edges() []ent.Edge {
	return []ent.Edge{
		// Une équipe appartient à un commissariat
		edge.From("commissariat", Commissariat.Type).
			Ref("equipes").
			Unique(),
		// Une équipe a un chef d'équipe (User)
		edge.To("chef_equipe", User.Type).
			Unique(),
		// Une équipe a plusieurs membres (Users)
		edge.To("membres", User.Type),
		// Une équipe peut avoir plusieurs missions
		edge.To("missions", Mission.Type),
	}
}

// Indexes of the Equipe.
func (Equipe) Indexes() []ent.Index {
	return []ent.Index{
		// Note: "code" index is provided by CodeMixin
		index.Fields("active"),
	}
}
