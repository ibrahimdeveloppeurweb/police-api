package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// Conducteur holds the schema definition for the Conducteur entity.
type Conducteur struct {
	ent.Schema
}

// Mixin of the Conducteur.
func (Conducteur) Mixin() []ent.Mixin {
	return []ent.Mixin{
		CodeMixin{},
	}
}

// Fields of the Conducteur.
func (Conducteur) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		field.String("nom").
			NotEmpty(),
		field.String("prenom").
			NotEmpty(),
		field.Time("date_naissance"),
		field.String("lieu_naissance").
			Optional(),
		field.String("adresse").
			Optional(),
		field.String("code_postal").
			Optional(),
		field.String("ville").
			Optional(),
		field.String("telephone").
			Optional(),
		field.String("email").
			Optional(),
		field.String("numero_cni").
			Optional(),
		field.String("numero_permis").
			Optional(),
		field.Time("permis_delivre_le").
			Optional(),
		field.Time("permis_valide_jusqu").
			Optional(),
		field.String("categories_permis").
			Optional(), // A, B, C, D, etc.
		field.Int("points_permis").
			Default(12),
		field.String("nationalite").
			Default("FR"),
		field.Bool("active").
			Default(true),
		field.Time("created_at").
			Default(time.Now),
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now),
	}
}

// Edges of the Conducteur.
func (Conducteur) Edges() []ent.Edge {
	return []ent.Edge{
		// Un conducteur peut avoir plusieurs contrôles
		edge.To("controles", Controle.Type),
		// Un conducteur peut avoir plusieurs infractions
		edge.To("infractions", Infraction.Type),
	}
}

// Indexes of the Conducteur.
func (Conducteur) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("nom", "prenom"),
		index.Fields("date_naissance"),
		index.Fields("numero_permis"),
		index.Fields("email"),
	}
}