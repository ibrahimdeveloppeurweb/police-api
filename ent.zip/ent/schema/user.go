package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// User holds the schema definition for the User entity.
type User struct {
	ent.Schema
}

// Mixin of the User.
func (User) Mixin() []ent.Mixin {
	return []ent.Mixin{
		CodeMixin{},
	}
}

// Fields of the User.
func (User) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		field.String("matricule").
			Unique(),
		field.String("nom"),
		field.String("prenom"),
		field.String("email").
			Unique(),
		field.String("password").
			Sensitive(),
		field.String("role").
			Default("agent").
			Comment("Rôle: admin, commissaire, agent, superviseur"),
		field.String("grade").
			Optional().
			Comment("Grade: Gardien, Brigadier, Sergent, Adjudant, Lieutenant, Capitaine, Commandant, Commissaire"),
		field.String("telephone").
			Optional(),
		// Nouveaux champs pour informations personnelles
		field.Time("date_naissance").
			Optional().
			Comment("Date de naissance de l'agent"),
		field.String("cni").
			Optional().
			Comment("Numéro de carte d'identité nationale"),
		field.String("adresse").
			Optional().
			Comment("Adresse personnelle de l'agent"),
		field.Time("date_entree").
			Optional().
			Comment("Date d'entrée dans la police"),
		// Champs existants
		field.String("statut_service").
			Default("HORS_SERVICE").
			Comment("Statut: EN_SERVICE, EN_PAUSE, HORS_SERVICE"),
		field.String("localisation").
			Optional().
			Comment("Localisation actuelle de l'agent"),
		field.String("activite").
			Optional().
			Comment("Activité en cours: Patrouille, Contrôle fixe, Investigation, etc."),
		field.Time("derniere_activite").
			Optional().
			Comment("Timestamp de la dernière activité"),
		field.Float("gps_precision").
			Default(0).
			Comment("Précision GPS en pourcentage: 0-100"),
		field.String("temps_service").
			Optional().
			Comment("Temps de service aujourd'hui: 2h15, 8h00, etc."),
		field.Bool("active").
			Default(true),
		field.Time("created_at").
			Default(time.Now),
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now),
	}
}

// Edges of the User.
func (User) Edges() []ent.Edge {
	return []ent.Edge{
		// Un utilisateur appartient à un commissariat
		edge.From("commissariat", Commissariat.Type).
			Ref("agents").
			Unique(),
		// Un utilisateur peut effectuer plusieurs contrôles
		edge.To("controles", Controle.Type),
		// Un utilisateur peut uploader plusieurs documents
		edge.To("documents", Document.Type),
		// Un utilisateur peut traiter plusieurs recours
		edge.To("recours_traites", Recours.Type),
		// Un utilisateur a des logs d'audit
		edge.To("audit_logs", AuditLog.Type),
		// Un utilisateur peut créer plusieurs alertes
		edge.To("alertes", AlerteSecuritaire.Type),
		// Un utilisateur peut avoir des plaintes assignées
		edge.To("plaintes_assignees", Plainte.Type),
		// Un utilisateur peut créer plusieurs convocations
		edge.To("convocations_creees", Convocation.Type),
		// Un utilisateur peut réaliser plusieurs inspections
		edge.To("inspections_realisees", Inspection.Type),

		// =============== NOUVELLES RELATIONS ===============
		// Un utilisateur a un supérieur hiérarchique (self-referencing)
		edge.To("subordonnes", User.Type).
			From("superieur").
			Unique(),
		// Un utilisateur peut appartenir à une équipe (membre)
		edge.From("equipe", Equipe.Type).
			Ref("membres").
			Unique(),
		// Un utilisateur peut avoir plusieurs missions (many-to-many)
		edge.From("missions", Mission.Type).
			Ref("agents"),
		// Un utilisateur peut avoir plusieurs objectifs
		edge.To("objectifs", Objectif.Type),
		// Un utilisateur peut avoir plusieurs observations (reçues)
		edge.To("observations", Observation.Type),
		// Un utilisateur peut avoir plusieurs compétences (many-to-many)
		edge.To("competences", Competence.Type),
	}
}

// Indexes of the User.
func (User) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("matricule"),
		index.Fields("email"),
		index.Fields("role"),
		index.Fields("active"),
		index.Fields("statut_service"),
	}
}
