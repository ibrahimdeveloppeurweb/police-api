package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// InfractionType holds the schema definition for the InfractionType entity.
// Note: InfractionType has its own 'code' field (infraction code like "EXC_VIT")
// so it doesn't use CodeMixin
type InfractionType struct {
	ent.Schema
}

// Fields of the InfractionType.
func (InfractionType) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		field.String("code").
			Unique(),
		field.String("libelle"),
		field.String("description").
			Optional(),
		field.Float("amende").
			Positive(),
		field.Int("points").
			Min(0).
			Default(0),
		field.String("categorie"),
		field.Bool("active").
			Default(true),
		field.Time("created_at").
			Default(time.Now),
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now),
	}
}

// Edges of the InfractionType.
func (InfractionType) Edges() []ent.Edge {
	return []ent.Edge{
		// Un type d'infraction peut avoir plusieurs infractions
		edge.To("infractions", Infraction.Type),
		// Un type d'infraction peut être lié à plusieurs CheckItems
		edge.To("check_items", CheckItem.Type),
	}
}

// Indexes of the InfractionType.
func (InfractionType) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("code"),
		index.Fields("categorie"),
		index.Fields("active"),
	}
}