package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// Convocation holds the schema definition for the Convocation entity.
type Convocation struct {
	ent.Schema
}

// Mixin of the Convocation.
func (Convocation) Mixin() []ent.Mixin {
	return []ent.Mixin{
		CodeMixin{},
	}
}

// Fields of the Convocation.
func (Convocation) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		field.String("numero").
			Unique(),
		field.Enum("type_convocation").
			Values("AUDITION_TEMOIN", "AUDITION_SUSPECT", "CONFRONTATION", "EXPERTISE", "AUTRE").
			Default("AUDITION_TEMOIN"),
		// Personne convoquée
		field.String("convoque_nom"),
		field.String("convoque_prenom"),
		field.String("convoque_telephone").
			Optional(),
		field.String("convoque_adresse").
			Optional(),
		field.String("convoque_email").
			Optional(),
		field.Enum("qualite_convoque").
			Values("TEMOIN", "SUSPECT", "VICTIME", "EXPERT", "AUTRE").
			Default("TEMOIN"),
		// Dates
		field.Time("date_creation").
			Default(time.Now),
		field.Time("date_rdv").
			Optional().
			Nillable(),
		field.String("heure_rdv").
			Optional(),
		field.Time("date_envoi").
			Optional().
			Nillable(),
		field.Time("date_honoration").
			Optional().
			Nillable(),
		// Statut
		field.Enum("statut").
			Values("BROUILLON", "ENVOYE", "RECU", "HONORE", "NON_HONORE", "REPORTE", "ANNULE").
			Default("BROUILLON"),
		// Lieu
		field.String("lieu_rdv").
			Optional(),
		// Motif et observations
		field.String("motif").
			Optional(),
		field.String("observations").
			Optional(),
		field.String("resultat_audition").
			Optional(),
		// Mode d'envoi
		field.Enum("mode_envoi").
			Values("COURRIER", "EMAIL", "SMS", "MAIN_PROPRE", "HUISSIER").
			Default("COURRIER"),
		field.String("reference_envoi").
			Optional(),
		// Timestamps
		field.Time("created_at").
			Default(time.Now),
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now),
	}
}

// Edges of the Convocation.
func (Convocation) Edges() []ent.Edge {
	return []ent.Edge{
		// Une convocation appartient à une plainte
		edge.From("plainte", Plainte.Type).
			Ref("convocations").
			Unique(),
		// Une convocation est créée par un agent
		edge.From("agent", User.Type).
			Ref("convocations_creees").
			Unique(),
		// Commissariat de rattachement
		edge.From("commissariat", Commissariat.Type).
			Ref("convocations").
			Unique(),
	}
}

// Indexes of the Convocation.
func (Convocation) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("numero"),
		index.Fields("type_convocation"),
		index.Fields("statut"),
		index.Fields("date_rdv"),
		index.Fields("date_creation"),
	}
}
