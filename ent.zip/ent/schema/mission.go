package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// Mission holds the schema definition for the Mission entity.
type Mission struct {
	ent.Schema
}

// Mixin of the Mission.
func (Mission) Mixin() []ent.Mixin {
	return []ent.Mixin{
		CodeMixin{},
	}
}

// Fields of the Mission.
func (Mission) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		field.String("type").
			NotEmpty().
			Comment("Type de mission: Patrouille mobile, Contrôle fixe, Surveillance événement, Opération spéciale, Investigation, Formation"),
		field.String("titre").
			Optional().
			Comment("Titre ou description courte de la mission"),
		field.String("description").
			Optional().
			Comment("Description détaillée de la mission"),
		field.Time("date_debut").
			Comment("Date et heure de début de la mission"),
		field.Time("date_fin").
			Optional().
			Comment("Date et heure de fin de la mission"),
		field.String("duree").
			Optional().
			Comment("Durée prévue ou réelle: 2h15, 4h00, etc."),
		field.String("zone").
			Optional().
			Comment("Zone d'intervention: Zone Centre, Boulevard Principal, etc."),
		field.String("statut").
			Default("PLANIFIEE").
			Comment("Statut: PLANIFIEE, EN_COURS, TERMINEE, ANNULEE"),
		field.String("rapport").
			Optional().
			Comment("Rapport de fin de mission"),
		field.Time("created_at").
			Default(time.Now),
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now),
	}
}

// Edges of the Mission.
func (Mission) Edges() []ent.Edge {
	return []ent.Edge{
		// Une mission peut avoir plusieurs agents (many-to-many)
		edge.To("agents", User.Type),
		// Une mission peut être liée à un commissariat
		edge.From("commissariat", Commissariat.Type).
			Ref("missions").
			Unique(),
		// Une mission peut être liée à une équipe
		edge.From("equipe", Equipe.Type).
			Ref("missions").
			Unique(),
	}
}

// Indexes of the Mission.
func (Mission) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("type"),
		index.Fields("statut"),
		index.Fields("date_debut"),
	}
}
