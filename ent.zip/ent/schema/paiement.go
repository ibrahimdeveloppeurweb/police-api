package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// Paiement holds the schema definition for the Paiement entity.
type Paiement struct {
	ent.Schema
}

// Mixin of the Paiement.
func (Paiement) Mixin() []ent.Mixin {
	return []ent.Mixin{
		CodeMixin{},
	}
}

// Fields of the Paiement.
func (Paiement) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		field.String("numero_transaction").
			Unique().
			NotEmpty(),
		field.Time("date_paiement").
			Default(time.Now),
		field.Float("montant").
			Positive(),
		field.String("moyen_paiement").
			NotEmpty(), // CB, CHEQUE, ESPECES, VIREMENT, PAYPAL
		field.String("reference_externe").
			Optional(), // Référence banque/prestataire
		field.String("statut").
			Default("EN_COURS"), // EN_COURS, VALIDE, REFUSE, REMBOURSE
		field.String("code_autorisation").
			Optional(),
		field.Text("details_paiement").
			Optional(), // JSON avec détails spécifiques
		field.Time("date_validation").
			Optional(),
		field.String("motif_refus").
			Optional(),
		field.Time("created_at").
			Default(time.Now),
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now),
	}
}

// Edges of the Paiement.
func (Paiement) Edges() []ent.Edge {
	return []ent.Edge{
		// Un paiement appartient à un PV
		edge.From("proces_verbal", ProcesVerbal.Type).
			Ref("paiements").
			Unique().
			Required(),
	}
}

// Indexes of the Paiement.
func (Paiement) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("numero_transaction"),
		index.Fields("date_paiement"),
		index.Fields("statut"),
		index.Fields("moyen_paiement"),
		index.Fields("reference_externe"),
	}
}