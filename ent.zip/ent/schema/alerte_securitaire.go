package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// AlerteSecuritaire holds the schema definition for the AlerteSecuritaire entity.
type AlerteSecuritaire struct {
	ent.Schema
}

// Mixin of the AlerteSecuritaire.
func (AlerteSecuritaire) Mixin() []ent.Mixin {
	return []ent.Mixin{
		CodeMixin{},
	}
}

// Fields of the AlerteSecuritaire.
func (AlerteSecuritaire) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		field.String("titre"),
		field.String("description").
			Optional(),
		field.Enum("niveau").
			Values("FAIBLE", "MOYEN", "ELEVE", "CRITIQUE").
			Default("MOYEN"),
		field.Enum("statut").
			Values("ACTIVE", "RESOLUE", "ARCHIVEE").
			Default("ACTIVE"),
		field.String("type_alerte"),
		field.String("localisation").
			Optional(),
		field.Float("latitude").
			Optional(),
		field.Float("longitude").
			Optional(),
		field.Time("date_alerte").
			Default(time.Now),
		field.Time("date_resolution").
			Optional().
			Nillable(),
		field.Bool("diffusee").
			Default(false),
		field.Time("date_diffusion").
			Optional().
			Nillable(),
		field.Time("created_at").
			Default(time.Now),
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now),
	}
}

// Edges of the AlerteSecuritaire.
func (AlerteSecuritaire) Edges() []ent.Edge {
	return []ent.Edge{
		// Une alerte appartient à un commissariat
		edge.From("commissariat", Commissariat.Type).
			Ref("alertes").
			Unique(),
		// Une alerte est créée par un agent
		edge.From("agent", User.Type).
			Ref("alertes").
			Unique(),
	}
}

// Indexes of the AlerteSecuritaire.
func (AlerteSecuritaire) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("niveau"),
		index.Fields("statut"),
		index.Fields("type_alerte"),
		index.Fields("date_alerte"),
	}
}
