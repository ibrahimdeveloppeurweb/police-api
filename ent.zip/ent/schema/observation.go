package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// Observation holds the schema definition for the Observation entity.
type Observation struct {
	ent.Schema
}

// Mixin of the Observation.
func (Observation) Mixin() []ent.Mixin {
	return []ent.Mixin{
		CodeMixin{},
	}
}

// Fields of the Observation.
func (Observation) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New),
		field.String("contenu").
			NotEmpty().
			Comment("Contenu de l'observation"),
		field.String("type").
			Default("NEUTRE").
			Comment("Type d'observation: POSITIVE, NEGATIVE, NEUTRE, AVERTISSEMENT, FELICITATION"),
		field.String("categorie").
			Optional().
			Comment("Catégorie: Performance, Comportement, Ponctualité, Discipline, etc."),
		field.String("periode").
			Optional().
			Comment("Période concernée: jour, semaine, mois, annee"),
		field.Time("date_observation").
			Default(time.Now).
			Comment("Date de l'observation"),
		field.Bool("visible_agent").
			Default(true).
			Comment("Si l'observation est visible par l'agent concerné"),
		field.Time("created_at").
			Default(time.Now),
		field.Time("updated_at").
			Default(time.Now).
			UpdateDefault(time.Now),
	}
}

// Edges of the Observation.
func (Observation) Edges() []ent.Edge {
	return []ent.Edge{
		// Une observation concerne un agent
		edge.From("agent", User.Type).
			Ref("observations").
			Unique().
			Required(),
		// Une observation est faite par un auteur (supérieur)
		edge.To("auteur", User.Type).
			Unique().
			Required(),
	}
}

// Indexes of the Observation.
func (Observation) Indexes() []ent.Index {
	return []ent.Index{
		index.Fields("type"),
		index.Fields("date_observation"),
	}
}
